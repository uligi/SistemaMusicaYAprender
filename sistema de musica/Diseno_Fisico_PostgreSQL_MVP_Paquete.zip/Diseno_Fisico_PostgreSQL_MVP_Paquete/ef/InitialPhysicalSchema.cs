using System;
using System.IO;
using System.Linq;
using System.Reflection;
using Microsoft.EntityFrameworkCore.Migrations;

namespace JapaneseMusic.Infrastructure.Persistence.Migrations;

[Migration("202607220001_InitialPhysicalSchema")]
public sealed class InitialPhysicalSchema : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql(LoadEmbeddedSql("01_initial_schema.sql"));
        migrationBuilder.Sql(LoadEmbeddedSql("02_seed_mvp.sql"));
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        // Permitido únicamente en desarrollo o pruebas desechables.
        migrationBuilder.Sql(LoadEmbeddedSql("99_rollback_dev_only.sql"));
    }

    private static string LoadEmbeddedSql(string fileName)
    {
        var assembly = typeof(InitialPhysicalSchema).Assembly;
        var resourceName = assembly.GetManifestResourceNames()
            .Single(name => name.EndsWith(fileName, StringComparison.Ordinal));
        using var stream = assembly.GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException($"No se encontró {fileName} como recurso embebido.");
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }
}
