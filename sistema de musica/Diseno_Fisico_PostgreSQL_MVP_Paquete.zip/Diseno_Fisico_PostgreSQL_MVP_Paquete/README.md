# Paquete de diseño físico PostgreSQL 18 del MVP

Orden de uso:

1. Un DBA ejecuta `sql/00_bootstrap_roles_extensions.sql` una sola vez por base.
2. El proyecto incluye los tres SQL de migración como recursos embebidos.
3. El rol LOGIN del despliegue recibe `jp_migrator`; las aplicaciones reciben solo `jp_app`, `jp_backoffice` o `jp_worker` según su proceso.
4. Se agrega `ef/InitialPhysicalSchema.cs` al proyecto de infraestructura y se ajusta únicamente el namespace.
5. Se ejecuta la migración en CI mediante script idempotente revisado o migration bundle; no desde el arranque de la API en producción.

Fragmento de proyecto:

```xml
<ItemGroup>
  <EmbeddedResource Include="Database/Migrations/sql/01_initial_schema.sql" />
  <EmbeddedResource Include="Database/Migrations/sql/02_seed_mvp.sql" />
  <EmbeddedResource Include="Database/Migrations/sql/99_rollback_dev_only.sql" />
</ItemGroup>
```

Configuración EF Core mínima:

```csharp
options.UseNpgsql(connectionString,
    npgsql => npgsql.MigrationsHistoryTable("__ef_migrations_history", "ops"));
```

La conexión de cada petición autenticada debe abrir una transacción y ejecutar
`SET LOCAL app.account_id = '<uuid>'` antes de consultar tablas con RLS. Los
procesos de backoffice y worker usan credenciales de base separadas.

`99_rollback_dev_only.sql` elimina los nueve esquemas con `CASCADE`; nunca se
ejecuta en producción. Los roles globales y extensiones no se eliminan.
